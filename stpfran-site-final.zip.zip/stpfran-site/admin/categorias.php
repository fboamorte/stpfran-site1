<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

// Buscar todas as categorias
$result = $conn->query("SELECT * FROM categorias ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Categorias</title>
</head>
<body>
<h2>Gerenciar Categorias</h2>

<p><a href="dashboard.php">← Voltar ao painel</a> | <a href="categoria_add.php">+ Adicionar Categoria</a></p>

<table border="1" cellpadding="6">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Ações</th>
    </tr>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nome']) ?></td>
                <td>
                    <a href="categoria_edit.php?id=<?= $row['id'] ?>">Editar</a> |
                    <a href="categoria_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Apagar esta categoria?')">Apagar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="3">Nenhuma categoria encontrada.</td></tr>
    <?php endif; ?>
</table>
</body>
</html>
