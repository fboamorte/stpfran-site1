<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

$id = $_GET['id'] ?? 0;
$id = intval($id);

// Primeiro, buscar o nome da imagem
$stmt = $conn->prepare("SELECT imagem FROM produtos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $imagem = $row['imagem'];

    // Apagar imagem (se existir)
    if ($imagem && file_exists("../uploads/" . $imagem)) {
        unlink("../uploads/" . $imagem);
    }

    // Agora apagar o produto
    $del = $conn->prepare("DELETE FROM produtos WHERE id = ?");
    $del->bind_param("i", $id);
    if ($del->execute()) {
        header("Location: produtos.php?msg=apagado");
        exit();
    } else {
        echo "Erro ao apagar o produto.";
    }
} else {
    echo "Produto não encontrado.";
}
