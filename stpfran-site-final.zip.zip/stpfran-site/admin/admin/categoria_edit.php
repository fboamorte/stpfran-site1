<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
include '../includes/config.php';
$id = intval($_GET['id'] ?? 0); $erro = ''; $sucesso = '';
$stmt = $conn->prepare("SELECT * FROM categorias WHERE id = ?");
$stmt->bind_param("i", $id); $stmt->execute();
$result = $stmt->get_result(); $categoria = $result->fetch_assoc();
if (!$categoria) { echo "Categoria não encontrada."; exit(); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    if ($nome == '') { $erro = "O nome é obrigatório."; }
    else {
        $stmt = $conn->prepare("UPDATE categorias SET nome = ? WHERE id = ?");
        $stmt->bind_param("si", $nome, $id);
        if ($stmt->execute()) { $sucesso = "Categoria atualizada."; $categoria['nome'] = $nome; }
        else { $erro = "Erro ao atualizar."; }
    }
}
?><!DOCTYPE html><html><head><title>Editar Categoria</title></head><body>
<h2>Editar Categoria</h2><p><a href="categorias.php">← Voltar à lista</a></p>
<?php if ($erro): ?><p style="color:red"><?= $erro ?></p><?php endif; ?>
<?php if ($sucesso): ?><p style="color:green"><?= $sucesso ?></p><?php endif; ?>
<form method="POST">
<label>Nome da categoria: <input type="text" name="nome" value="<?= htmlspecialchars($categoria['nome']) ?>" required></label><br><br>
<button type="submit">Salvar alterações</button></form></body></html>