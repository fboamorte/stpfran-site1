<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
include '../includes/config.php';
$erro = ''; $sucesso = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    if ($nome == '') { $erro = "O nome da categoria é obrigatório."; }
    else {
        $stmt = $conn->prepare("INSERT INTO categorias (nome) VALUES (?)");
        $stmt->bind_param("s", $nome);
        if ($stmt->execute()) { $sucesso = "Categoria adicionada com sucesso."; $nome = ''; }
        else { $erro = "Erro ao salvar."; }
    }
}
?><!DOCTYPE html><html><head><title>Adicionar Categoria</title></head><body>
<h2>Adicionar Categoria</h2>
<p><a href="categorias.php">← Voltar à lista</a></p>
<?php if ($erro): ?><p style="color:red"><?= $erro ?></p><?php endif; ?>
<?php if ($sucesso): ?><p style="color:green"><?= $sucesso ?></p><?php endif; ?>
<form method="POST">
<label>Nome da categoria: <input type="text" name="nome" value="<?= htmlspecialchars($nome ?? '') ?>" required></label><br><br>
<button type="submit">Salvar</button></form></body></html>