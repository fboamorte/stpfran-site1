<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
include '../includes/config.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("DELETE FROM categorias WHERE id = ?");
$stmt->bind_param("i", $id);
if ($stmt->execute()) { header("Location: categorias.php"); exit(); }
else { echo "Erro ao apagar a categoria."; }