<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

$id = $_GET['id'] ?? 0;
$id = intval($id);

// Buscar produto
$stmt = $conn->prepare("SELECT * FROM produtos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$produto = $result->fetch_assoc();

if (!$produto) {
    echo "Produto não encontrado.";
    exit();
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $descricao = $_POST['descricao'] ?? '';
    $categoria_id = $_POST['categoria_id'] ?? '';

    if (!$nome || !$categoria_id) {
        $erro = "Nome e categoria são obrigatórios.";
    } else {
        $imagem_nome = $produto['imagem']; // imagem antiga

        // Upload de nova imagem?
        if (!empty($_FILES['imagem']['name'])) {
            $ext = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            $permitidas = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($ext, $permitidas)) {
                // Apagar imagem antiga (opcional)
                if ($imagem_nome && file_exists("../uploads/" . $imagem_nome)) {
                    unlink("../uploads/" . $imagem_nome);
                }

                $imagem_nome = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['imagem']['tmp_name'], "../uploads/" . $imagem_nome);
            } else {
                $erro = "Extensão de imagem inválida.";
            }
        }

        if (!$erro) {
            $stmt = $conn->prepare("UPDATE produtos SET nome = ?, descricao = ?, imagem = ?, categoria_id = ? WHERE id = ?");
            $stmt->bind_param("sssii", $nome, $descricao, $imagem_nome, $categoria_id, $id);
            if ($stmt->execute()) {
                $sucesso = "Produto atualizado com sucesso!";
                // Atualizar dados exibidos
                $produto['nome'] = $nome;
                $produto['descricao'] = $descricao;
                $produto['imagem'] = $imagem_nome;
                $produto['categoria_id'] = $categoria_id;
            } else {
                $erro = "Erro ao atualizar.";
            }
            $stmt->close();
        }
    }
}

// Buscar categorias
$categorias = $conn->query("SELECT id, nome FROM categorias ORDER BY nome ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Produto</title>
</head>
<body>
<h2>Editar Produto</h2>
<p><a href="produtos.php">← Voltar à lista</a></p>

<?php if ($erro): ?>
    <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
<?php elseif ($sucesso): ?>
    <p style="color:green;"><?= htmlspecialchars($sucesso) ?></p>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <label>Nome:<br>
        <input type="text" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>
    </label><br><br>

    <label>Descrição:<br>
        <textarea name="descricao"><?= htmlspecialchars($produto['descricao']) ?></textarea>
    </label><br><br>

    <label>Categoria:<br>
        <select name="categoria_id" required>
            <option value="">-- Selecione --</option>
            <?php while ($cat = $categorias->fetch_assoc()): ?>
                <option value="<?= $cat['id'] ?>" <?= ($produto['categoria_id'] == $cat['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['nome']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </label><br><br>

    <label>Imagem atual:<br>
        <?php if ($produto['imagem']): ?>
            <img src="../uploads/<?= htmlspecialchars($produto['imagem']) ?>" alt="Imagem" width="100"><br>
        <?php else: ?>
            Nenhuma imagem.<br>
        <?php endif; ?>
        <input type="file" name="imagem" accept="image/*">
        <small>(Deixe em branco para manter a imagem atual)</small>
    </label><br><br>

    <button type="submit">Salvar Alterações</button>
</form>

</body>
</html>
