<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

// Buscar produtos com suas categorias
$sql = "SELECT p.id, p.nome, p.descricao, p.imagem, c.nome AS categoria FROM produtos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        ORDER BY p.id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Produtos - Painel Admin</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background-color: #eee; }
        img { max-width: 100px; }
        a { text-decoration: none; color: blue; }
    </style>
</head>
<body>
<h2>Produtos</h2>

<p><a href="produto_add.php">+ Adicionar Produto</a> | <a href="dashboard.php">Voltar ao Painel</a></p>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Categoria</th>
            <th>Imagem</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['nome']) ?></td>
            <td><?= nl2br(htmlspecialchars($row['descricao'])) ?></td>
            <td><?= htmlspecialchars($row['categoria']) ?></td>
            <td>
                <?php if ($row['imagem']): ?>
                    <img src="../uploads/<?= htmlspecialchars($row['imagem']) ?>" alt="Imagem">
                <?php else: ?>
                    ---
                <?php endif; ?>
            </td>
            <td>
                <a href="produto_edit.php?id=<?= $row['id'] ?>">Editar</a> |
                <a href="produto_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Tem certeza que deseja apagar este produto?')">Apagar</a>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="6">Nenhum produto cadastrado.</td></tr>
    <?php endif; ?>
    </tbody>
</table>

</body>
</html>
