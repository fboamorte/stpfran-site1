<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "stpfran"; // ou o nome que você deu ao banco de dados

$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
?>
