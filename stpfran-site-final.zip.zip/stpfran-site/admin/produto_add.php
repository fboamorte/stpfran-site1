<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include '../includes/config.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $descricao = $_POST['descricao'] ?? '';
    $categoria_id = $_POST['categoria_id'] ?? '';

    // Validação simples
    if (!$nome || !$categoria_id) {
        $erro = "Por favor, preencha o nome e selecione a categoria.";
    } else {
        // Upload da imagem
        $imagem_nome = '';
        if (!empty($_FILES['imagem']['name'])) {
            $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
            $ext = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $extensoes_permitidas)) {
                $imagem_nome = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['imagem']['tmp_name'], "../uploads/" . $imagem_nome);
            } else {
                $erro = "Extensão de imagem não permitida.";
            }
        }

        if (!$erro) {
            $stmt = $conn->prepare("INSERT INTO produtos (nome, descricao, imagem, categoria_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $nome, $descricao, $imagem_nome, $categoria_id);
            if ($stmt->execute()) {
                $sucesso = "Produto cadastrado com sucesso!";
                // Limpar campos
                $nome = $descricao = '';
                $categoria_id = '';
            } else {
                $erro = "Erro ao salvar o produto.";
            }
            $stmt->close();
        }
    }
}

// Buscar categorias para o select
$categorias = $conn->query("SELECT id, nome FROM categorias ORDER BY nome ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Produto - Painel Admin</title>
</head>
<body>
<h2>Adicionar Produto</h2>

<p><a href="produtos.php">Voltar à lista de produtos</a></p>

<?php if ($erro): ?>
    <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
<?php elseif ($sucesso): ?>
    <p style="color:green;"><?= htmlspecialchars($sucesso) ?></p>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <label>Nome:<br>
        <input type="text" name="nome" value="<?= htmlspecialchars($nome ?? '') ?>" required>
    </label><br><br>

    <label>Descrição:<br>
        <textarea name="descricao"><?= htmlspecialchars($descricao ?? '') ?></textarea>
    </label><br><br>

    <label>Categoria:<br>
        <select name="categoria_id" required>
            <option value="">-- Selecione --</option>
            <?php while ($cat = $categorias->fetch_assoc()): ?>
                <option value="<?= $cat['id'] ?>" <?= (isset($categoria_id) && $categoria_id == $cat['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['nome']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </label><br><br>

    <label>Imagem:<br>
        <input type="file" name="imagem" accept="image/*">
    </label><br><br>

    <button type="submit">Salvar Produto</button>
</form>

</body>
</html>
