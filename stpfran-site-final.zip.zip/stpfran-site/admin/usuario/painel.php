<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['nivel'] !== 'visualizador') {
    header('Location: ../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Painel do Usuário</title>
</head>
<body>
    <h2>Bem-vindo ao Painel do Usuário, <?= $_SESSION['email']; ?></h2>
    <p><a href="../logout.php">Sair</a></p>
</body>
</html>
