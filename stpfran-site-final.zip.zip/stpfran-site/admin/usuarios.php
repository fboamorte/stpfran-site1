<?php
include('../conexao.php');
$result = $conn->query("SELECT * FROM usuarios");
?>
<h2>Gestão de Usuários</h2>
<a href="usuario_add.php">+ Adicionar Usuário</a> | <a href="painel.php">Voltar</a>
<table border="1">
<tr><th>ID</th><th>Nome</th><th>Email</th><th>Ações</th></tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['nome'] ?></td>
<td><?= $row['email'] ?></td>
<td>
 <a href="usuario_edit.php?id=<?= $row['id'] ?>">Editar</a> /
 <a href="usuario_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Deseja excluir?')">Apagar</a>
</td>
</tr>
<?php endwhile; ?>
</table>
