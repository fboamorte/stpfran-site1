<?php
include('../conexao.php');
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM usuarios WHERE id=$id");
$row = $result->fetch_assoc();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $nome = $_POST['nome'];
 $email = $_POST['email'];
 if (!empty($_POST['senha'])) {
   $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
   $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=?, senha=? WHERE id=?");
   $stmt->bind_param("sssi", $nome, $email, $senha, $id);
 } else {
   $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=? WHERE id=?");
   $stmt->bind_param("ssi", $nome, $email, $id);
 }
 $stmt->execute();
 header("Location: usuarios.php");
}
?>
<h2>Editar Usuário</h2>
<form method="post">
Nome: <input type="text" name="nome" value="<?= $row['nome'] ?>"><br>
Email: <input type="email" name="email" value="<?= $row['email'] ?>"><br>
Nova Senha (opcional): <input type="password" name="senha"><br>
<input type="submit" value="Salvar Alterações">
</form>
<a href="usuarios.php">Voltar</a>
