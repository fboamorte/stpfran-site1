<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head><title>Painel Admin</title></head>
<body>
<h2>Bem-vindo ao Painel, <?php echo $_SESSION['admin']; ?></h2>
<p><a href='logout.php'>Sair</a></p>
</body>
</html>
