<?php
$conn = new mysqli("localhost", "root", "", "stpfran");

$email = "admin@stpfran.com";
$senha_digitada = "123456";

$stmt = $conn->prepare("SELECT senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $senha_do_banco = $row['senha'];

    echo "Hash do banco: " . $senha_do_banco . "<br>";

    if (password_verify($senha_digitada, $senha_do_banco)) {
        echo "<strong>✅ Senha correta!</strong>";
    } else {
        echo "<strong>❌ Senha incorreta!</strong>";
    }
} else {
    echo "❌ Usuário não encontrado.";
}
